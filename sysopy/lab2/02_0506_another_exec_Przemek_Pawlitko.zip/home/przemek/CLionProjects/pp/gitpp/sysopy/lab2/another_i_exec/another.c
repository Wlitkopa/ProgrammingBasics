
#include <stdio.h>
#include <unistd.h>


int main(){

    printf("Hello! I'm another program\n");

    int ch = getchar();

    return 0;
}